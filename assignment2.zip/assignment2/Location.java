import java.util.*;
public class Location {
    public static void main(String[] args) {
        
    }
}
class location{
    // data members
    private float x;
    private float y;

    // methods
    void set_location(float a,float b){
        this.x=a;
        this.y=b;
    }
    float get_x(){
         return this.x;
    }
    float get_y(){
        return this.y;
    }
}
